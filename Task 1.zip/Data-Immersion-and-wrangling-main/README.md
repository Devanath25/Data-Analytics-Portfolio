# Data-Immersion-and-wrangling
Apexplanet task-01 

# 📊 ApexPlanet Data Analytics Internship - Task 1
## Data Immersion & Wrangling

### 📌 Project Overview

This project is submitted as **Task 1** of the **ApexPlanet Data Analytics Internship Program**.

The objective of this task is to understand the provided dataset, assess its quality, clean and transform the data, and prepare an analysis-ready dataset for future business intelligence and exploratory data analysis.

---

## 🎯 Objectives

- Understand the dataset structure
- Create a Data Dictionary
- Identify missing values and duplicates
- Perform data cleaning and preprocessing
- Detect potential outliers
- Apply feature engineering
- Generate a clean dataset ready for analysis

---

## 📂 Dataset Information

The dataset contains customer purchase information, including:

- Order Details
- Customer Information
- Product Information
- Sales Details

### Columns

- Order_ID
- Order_Date
- Customer_ID
- Customer_Name
- Age
- Gender
- City
- Product
- Category
- Quantity
- Unit_Price
- Total_Sales

---

## 🛠️ Tools & Technologies

- Python
- Pandas
- NumPy
- Matplotlib
- Jupyter Notebook / Google Colab

---

## 📋 Data Cleaning Process

The following preprocessing steps were performed:

### ✅ Data Profiling

- Inspected dataset structure
- Checked data types
- Generated descriptive statistics

### ✅ Missing Value Handling

- Filled missing Age values using Median
- Filled missing City values using Mode

### ✅ Duplicate Check

- Checked duplicate rows
- Verified duplicate Order IDs

### ✅ Data Type Conversion

- Converted Order_Date to DateTime format

### ✅ Outlier Detection

Performed outlier analysis using Boxplots and the IQR (Interquartile Range) method for:

- Age
- Quantity
- Unit Price
- Total Sales

### ✅ Feature Engineering

Created additional features:

- Year
- Month
- Quarter
- Day
- Age Group

---

## 📊 Deliverables

This repository contains:

```
📁 Data_Dictionary.xlsx
📁 Cleaned_Sales_Dataset.xlsx
📁 Apextask1.ipynb
📁 ApexPlanet_DataAnalytics_Dataset.xlsx
📄 README.md
```

---

## 📈 Key Outcomes

- Cleaned and standardized the dataset
- Removed data inconsistencies
- Handled missing values
- Prepared data for Exploratory Data Analysis (EDA)
- Generated additional analytical features

---

## 🚀 Future Scope

The cleaned dataset will be used in the upcoming internship tasks for:

- Exploratory Data Analysis (EDA)
- Business Intelligence
- SQL Analysis
- Interactive Dashboard Development
- Data Storytelling

---

## 📷 Project Workflow

```
Raw Dataset
      │
      ▼
Data Profiling
      │
      ▼
Missing Value Analysis
      │
      ▼
Duplicate Detection
      │
      ▼
Data Cleaning
      │
      ▼
Feature Engineering
      │
      ▼
Outlier Detection
      │
      ▼
Cleaned Dataset
```

---

## 👨‍💻 Author

** R Devanath **

 E mail : devanathravi25@gmail.com

 linked In : https://www.linkedin.com/in/devanathr

ApexPlanet Data Analytics Internship

---

## ⭐ Acknowledgement

This project was completed as part of the **ApexPlanet Data Analytics Internship Program** to develop practical skills in data preprocessing, data quality assessment, and data wrangling using Python.
