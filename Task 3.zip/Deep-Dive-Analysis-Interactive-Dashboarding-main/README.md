# Deep-Dive-Analysis-Interactive-Dashboarding
Interactive Sales Analytics Dashboard - Task 3 

# 📊 ApexPlanet Data Analytics Internship – Task 3
## Deep-Dive Analysis & Interactive Dashboarding

---

## 📌 Project Overview

This repository showcases **Task 3** of the **ApexPlanet Data Analytics Internship Program**, where an interactive **Power BI dashboard** was developed to analyze business performance using a cleaned sales dataset.

The project focuses on defining Key Performance Indicators (KPIs), performing in-depth sales analysis, and building an interactive dashboard that helps visualize business trends and supports data-driven decision-making.

---

## 🎯 Objectives

- Define meaningful business KPIs
- Perform deep-dive analysis on sales data
- Create an interactive Power BI dashboard
- Visualize business performance through dynamic reports
- Enable users to explore data using filters and slicers

---

## 📂 Dataset

The dashboard is built using the **Cleaned Sales Dataset** prepared during **Task 1** of the internship.

### Dataset Includes

- Order Details
- Customer Information
- Product Details
- Sales Transactions
- Revenue Data
- Customer Demographics

---

## 🛠️ Tools & Technologies

- Microsoft Power BI Desktop
- Power Query
- DAX (Data Analysis Expressions)
- Microsoft Excel
- Python (Data Preparation)
- SQL
- GitHub

---

# 📊 Key Performance Indicators (KPIs)

The dashboard tracks the following KPIs:

- 💰 Total Revenue
- 📦 Total Orders
- 👥 Total Customers
- 💵 Average Order Value
- 📈 Total Quantity Sold
- 🎯 Average Customer Age

---

# 📈 Dashboard Features

### 📍 Executive Overview

- Total Revenue
- Total Orders
- Total Customers
- Average Order Value

### 📍 Sales Performance

- Monthly Revenue Trend
- Revenue by Category
- Revenue by City
- Revenue by Product

### 📍 Customer Analysis

- Revenue by Gender
- Revenue by Age Group
- Customer Distribution

### 📍 Product Analysis

- Top 10 Best-Selling Products
- Category Performance
- Product Contribution to Revenue

---

## 🎛 Interactive Dashboard Features

The dashboard allows users to filter and explore the data using:

- Year
- Month
- Category
- City
- Gender
- Age Group

These interactive filters provide flexible exploration of sales and customer trends.

---

## 📈 Business Insights

The dashboard helps answer important business questions such as:

- Which product category generates the highest revenue?
- Which city contributes the most sales?
- What are the top-selling products?
- Which customer age group contributes the highest revenue?
- How does monthly revenue change over time?
- What is the average order value?
- Which customer segments drive business growth?

---

## 📂 Repository Structure

```
Task3_Interactive_Dashboard/
│
├── README.md
├── Dashboard.pbix
├── Dashboard.pdf
├── Dashboard_Screenshots
├── Cleaned_Sales_Dataset.xlsx

```

---

## 🔄 Project Workflow

```
Cleaned Dataset
       │
       ▼
Power Query Transformation
       │
       ▼
Feature Engineering
       │
       ▼
DAX Measure Creation
       │
       ▼
KPI Development
       │
       ▼
Interactive Dashboard
       │
       ▼
Business Insights & Decision Support
```

---

## 🚀 Skills Demonstrated

- Business Intelligence
- Power BI Dashboard Development
- Power Query
- DAX Measures
- KPI Design
- Data Modeling
- Data Visualization
- Sales Performance Analysis
- Customer Analytics
- Interactive Reporting

---

## 📌 Future Enhancements

Possible improvements include:

- Real-time data refresh
- Sales forecasting using machine learning
- Profitability analysis
- Customer segmentation
- Geographic sales mapping
- Executive summary dashboard

---

## 👨‍💻 Author

R Devanath

E mail : devanathravi25@gmail.com

linked In : https://www.linkedin.com/in/devanathr


## 🙏 Acknowledgement

This project was completed as part of the **ApexPlanet Software Pvt. Ltd. Data Analytics Internship Program**. It demonstrates practical skills in Business Intelligence, KPI development, Power BI dashboard creation, and transforming business data into actionable insights.
